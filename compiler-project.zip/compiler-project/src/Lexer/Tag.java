/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lexer;

/**
 *
 *  eshghe aydin nazanin :X
 */
public class Tag {
    public final static int 
            NUM=256,ID=257,
            TRUE=258,FALSE=259,
            mod=300,div=301,
            sin=302,cos=303,
            tan=304,cot=305,REAL=306;
           
}
