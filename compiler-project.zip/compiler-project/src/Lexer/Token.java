/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Lexer;

/**
 *
 * @author Masoud
 */
public class Token {
    public final int tag;
    public Token(int t){
        tag = t;
    }
}
